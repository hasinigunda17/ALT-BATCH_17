Put official university documents here.
Examples: syllabus.pdf, attendance_rules.pdf, exam_schedule.pdf, library_rules.pdf

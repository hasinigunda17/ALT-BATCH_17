import os
from pathlib import Path
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from werkzeug.utils import secure_filename

from rag import build_index, ask_rag, index_exists

load_dotenv()

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024

BASE_DIR = Path(__file__).resolve().parent
DOCS_DIR = BASE_DIR / "documents"
DOCS_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"pdf", "txt", "docx"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat")
def chat():
    return render_template("chat.html")


@app.route("/documents")
def documents():
    files = sorted([f.name for f in DOCS_DIR.iterdir() if f.is_file()])
    return render_template("documents.html", files=files)


@app.route("/admin")
def admin():
    files = sorted([f.name for f in DOCS_DIR.iterdir() if f.is_file()])
    return render_template("admin.html", files=files)


@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("file")

    if not file or not file.filename:
        return jsonify({"success": False, "message": "Please choose a document."}), 400

    if not allowed_file(file.filename):
        return jsonify({
            "success": False,
            "message": "Only PDF, TXT and DOCX files are supported."
        }), 400

    filename = secure_filename(file.filename)
    file.save(DOCS_DIR / filename)

    try:
        build_index()
        return jsonify({
            "success": True,
            "message": f"{filename} uploaded and added to the knowledge base."
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"Document uploaded, but indexing failed: {str(e)}"
        }), 500


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()

    if not question:
        return jsonify({"success": False, "message": "Please enter a question."}), 400

    try:
        result = ask_rag(question)
        return jsonify({"success": True, **result})
    except Exception as e:
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500


@app.route("/rebuild", methods=["POST"])
def rebuild():
    try:
        build_index()
        return jsonify({"success": True, "message": "Knowledge base rebuilt successfully."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route("/status")
def status():
    files = [f for f in DOCS_DIR.iterdir() if f.is_file()]
    return jsonify({
        "documents": len(files),
        "index_ready": index_exists(),
        "gemini_ready": bool(os.getenv("GEMINI_API_KEY"))
    })


if __name__ == "__main__":
    app.run(debug=True)

The FAISS index is generated automatically after documents are indexed.
Do not manually edit this folder.

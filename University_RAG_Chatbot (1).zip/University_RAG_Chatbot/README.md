# UniAssist — RAG Chatbot for University Academic Assistance

A full-stack student project using Retrieval-Augmented Generation (RAG).

## Features

- Modern responsive frontend
- Flask backend
- PDF/DOCX/TXT document ingestion
- Text chunking
- Hugging Face sentence embeddings
- FAISS vector database
- Gemini LLM
- Source documents displayed with answers
- Admin document upload
- Knowledge-base rebuild
- System status page

## 1. Requirements

Install Python 3.10 or newer.

## 2. Create virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

## 3. Install packages

```bash
pip install -r requirements.txt
```

## 4. Configure Gemini

Copy `.env.example` to `.env`.

Then put your Gemini API key:

```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```

Never upload `.env` to GitHub.

## 5. Add university documents

Put official PDFs/DOCX/TXT files into:

```text
documents/
```

Recommended files:

- Academic Regulations
- Syllabus
- Academic Calendar
- Exam Schedule
- Attendance Rules
- Library Rules
- Fee Structure
- Placement Guidelines

## 6. Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

The first run may download the Hugging Face embedding model.

## How the RAG pipeline works

```text
University documents
       ↓
Text extraction
       ↓
Chunking
       ↓
Hugging Face embeddings
       ↓
FAISS vector database
       ↓
Student question
       ↓
Similarity search
       ↓
Relevant chunks
       ↓
Gemini
       ↓
Answer + source
```

## Important note

This project is intended as an academic demonstration. For a real university deployment, add authentication, role-based access, document versioning, audit logs, HTTPS, database storage, and stricter document access controls.

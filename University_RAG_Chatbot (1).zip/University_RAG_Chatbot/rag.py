import os
from pathlib import Path

from dotenv import load_dotenv
from pypdf import PdfReader
from docx import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document as LCDocument

from google import genai

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DOCS_DIR = BASE_DIR / "documents"
VECTOR_DIR = BASE_DIR / "vectorstore"

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def read_file(path):
    suffix = path.suffix.lower()
    text = ""

    if suffix == ".pdf":
        reader = PdfReader(str(path))
        pages = []
        for page in reader.pages:
            pages.append(page.extract_text() or "")
        text = "\n".join(pages)

    elif suffix == ".txt":
        text = path.read_text(encoding="utf-8", errors="ignore")

    elif suffix == ".docx":
        doc = Document(str(path))
        text = "\n".join(p.text for p in doc.paragraphs)

    return text.strip()


def get_embeddings():
    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True}
    )


def build_index():
    documents = []

    for path in sorted(DOCS_DIR.iterdir()):
        if not path.is_file() or path.suffix.lower() not in {".pdf", ".txt", ".docx"}:
            continue

        text = read_file(path)

        if not text:
            continue

        documents.append(
            LCDocument(
                page_content=text,
                metadata={"source": path.name}
            )
        )

    if not documents:
        raise ValueError("No readable documents found in the documents folder.")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=120
    )

    chunks = splitter.split_documents(documents)

    embeddings = get_embeddings()
    db = FAISS.from_documents(chunks, embeddings)
    db.save_local(str(VECTOR_DIR))

    return len(chunks)


def index_exists():
    return (
        (VECTOR_DIR / "index.faiss").exists()
        and (VECTOR_DIR / "index.pkl").exists()
    )


def get_database():
    if not index_exists():
        build_index()

    embeddings = get_embeddings()

    return FAISS.load_local(
        str(VECTOR_DIR),
        embeddings,
        allow_dangerous_deserialization=True
    )


def ask_rag(question):
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY is missing. Add your Gemini API key to the .env file."
        )

    db = get_database()

    results = db.similarity_search_with_score(question, k=4)

    # Lower FAISS distance means a better match.
    useful = [(doc, score) for doc, score in results if score < 1.30]

    if not useful:
        return {
            "answer": "I couldn't find this information in the university documents.",
            "sources": []
        }

    context_parts = []
    sources = []

    for doc, score in useful:
        context_parts.append(
            f"Source: {doc.metadata.get('source', 'University document')}\n"
            f"Content:\n{doc.page_content}"
        )

        source = doc.metadata.get("source", "University document")
        if source not in sources:
            sources.append(source)

    context = "\n\n---\n\n".join(context_parts)

    prompt = f"""
You are UniAssist, a university academic assistant.

Answer the student's question ONLY using the supplied university document context.

Rules:
1. Do not invent university-specific facts.
2. If the context does not contain enough information, say:
   "I couldn't find this information in the university documents."
3. Give a clear and concise answer.
4. Do not mention that you are using embeddings or a vector database.
5. Use simple language suitable for university students.

Student question:
{question}

University document context:
{context}
"""

    client = genai.Client(api_key=api_key)

    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        contents=prompt
    )

    answer = (response.text or "").strip()

    return {
        "answer": answer,
        "sources": sources
    }

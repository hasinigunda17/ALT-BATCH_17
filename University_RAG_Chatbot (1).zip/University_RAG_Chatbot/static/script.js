document.addEventListener("DOMContentLoaded", () => {
    const chatForm = document.getElementById("chatForm");
    const question = document.getElementById("question");
    const messages = document.getElementById("messages");
    const typing = document.getElementById("typing");
    const clearChat = document.getElementById("clearChat");

    function addMessage(type, text, sources = []) {
        const wrapper = document.createElement("div");
        wrapper.className = `message ${type}`;

        const avatar = type === "assistant" ? "✦" : "You";
        let sourceHTML = "";

        if (sources.length) {
            sourceHTML = `
                <div class="sources">
                    <span>Sources</span>
                    ${sources.map(s => `<div>▣ ${escapeHTML(s)}</div>`).join("")}
                </div>`;
        }

        wrapper.innerHTML = `
            <div class="avatar">${avatar}</div>
            <div class="message-body">
                <div class="name">${type === "assistant" ? "UniAssist" : "You"}</div>
                <div class="message-bubble">${formatText(text)}</div>
                ${sourceHTML}
            </div>
        `;

        messages.appendChild(wrapper);
        messages.scrollTop = messages.scrollHeight;
    }

    function escapeHTML(text) {
        return text.replace(/[&<>"']/g, char => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
        }[char]));
    }

    function formatText(text) {
        return escapeHTML(text).replace(/\n/g, "<br>");
    }

    if (chatForm) {
        chatForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const q = question.value.trim();
            if (!q) return;

            addMessage("user", q);
            question.value = "";
            typing.classList.add("show");

            try {
                const response = await fetch("/ask", {
                    method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({question: q})
                });

                const data = await response.json();

                if (data.success) {
                    addMessage("assistant", data.answer, data.sources || []);
                } else {
                    addMessage("assistant", data.message || "Something went wrong.");
                }
            } catch (error) {
                addMessage("assistant", "Unable to connect to the server. Please check that Flask is running.");
            } finally {
                typing.classList.remove("show");
            }
        });
    }

    document.querySelectorAll(".suggestion").forEach(button => {
        button.addEventListener("click", () => {
            if (question) {
                question.value = button.dataset.question;
                question.focus();
            }
        });
    });

    if (clearChat) {
        clearChat.addEventListener("click", () => {
            messages.innerHTML = `
                <div class="message assistant">
                    <div class="avatar">✦</div>
                    <div class="message-body">
                        <div class="name">UniAssist</div>
                        <div class="message-bubble">Chat cleared. What would you like to know?</div>
                    </div>
                </div>`;
        });
    }

    const fileInput = document.getElementById("fileInput");
    const fileName = document.getElementById("fileName");

    if (fileInput) {
        fileInput.addEventListener("change", () => {
            fileName.textContent = fileInput.files[0]
                ? fileInput.files[0].name
                : "Choose a document";
        });
    }

    const uploadForm = document.getElementById("uploadForm");

    if (uploadForm) {
        uploadForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const message = document.getElementById("uploadMessage");
            const button = uploadForm.querySelector("button");
            button.disabled = true;
            button.textContent = "Uploading & indexing...";

            try {
                const response = await fetch("/upload", {
                    method: "POST",
                    body: new FormData(uploadForm)
                });

                const data = await response.json();
                message.textContent = data.message;
                message.className = `result-message ${data.success ? "success" : "error"}`;

                if (data.success) setTimeout(() => location.reload(), 1200);
            } catch (error) {
                message.textContent = "Upload failed. Please try again.";
                message.className = "result-message error";
            } finally {
                button.disabled = false;
                button.textContent = "Upload & Build Knowledge Base";
            }
        });
    }

    const rebuildBtn = document.getElementById("rebuildBtn");

    if (rebuildBtn) {
        loadStatus();

        rebuildBtn.addEventListener("click", async () => {
            const msg = document.getElementById("rebuildMessage");
            rebuildBtn.disabled = true;
            rebuildBtn.textContent = "Rebuilding...";

            try {
                const response = await fetch("/rebuild", {method: "POST"});
                const data = await response.json();
                msg.textContent = data.message;
                msg.className = `result-message ${data.success ? "success" : "error"}`;
                loadStatus();
            } catch {
                msg.textContent = "Rebuild failed.";
                msg.className = "result-message error";
            } finally {
                rebuildBtn.disabled = false;
                rebuildBtn.textContent = "↻ Rebuild Knowledge Base";
            }
        });
    }

    async function loadStatus() {
        try {
            const response = await fetch("/status");
            const data = await response.json();

            document.getElementById("docCount").textContent = data.documents;
            document.getElementById("indexStatus").textContent = data.index_ready ? "Ready ✓" : "Not ready";
            document.getElementById("aiStatus").textContent = data.gemini_ready ? "Connected ✓" : "API key missing";
        } catch {}
    }
});
